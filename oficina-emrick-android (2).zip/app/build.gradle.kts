plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.oficinaemrick.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.oficinaemrick.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0.0"
    }

    // Chave fixa: assim cada APK novo instala por cima do antigo
    signingConfigs {
        create("oe") {
            storeFile = file("oe.keystore")
            storePassword = "oficinaemrick"
            keyAlias = "oe"
            keyPassword = "oficinaemrick"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("oe")
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("oe")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("io.getstream:stream-webrtc-android:1.3.10")
}
