package com.oficinaemrick.app

import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Surface
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.HardwareVideoEncoderFactory
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.RtpTransceiver
import org.webrtc.ScreenCapturerAndroid
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoEncoderFactory
import org.webrtc.VideoSource
import org.webrtc.VideoTrack
import org.webrtc.DataChannel
import java.util.concurrent.Executors

open class SimpleSdp : SdpObserver {
    override fun onCreateSuccess(sdp: SessionDescription) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(error: String?) {}
    override fun onSetFailure(error: String?) {}
}

/**
 * Captura a tela do celular e manda pra cada amigo da call
 * (uma conexão por amigo, só envio, codificação por hardware).
 */
class ScreenSharer(
    private val ctx: Context,
    private val sendSignal: (String, String) -> Unit,
    private val onStopped: () -> Unit
) {
    private class Viewer(val pc: PeerConnection) {
        var remoteSet = false
        val pending = ArrayList<IceCandidate>()
    }

    private val exec = Executors.newSingleThreadExecutor()
    private val egl: EglBase = EglBase.create()
    private val factory: PeerConnectionFactory
    private var capturer: ScreenCapturerAndroid? = null
    private var helper: SurfaceTextureHelper? = null
    private var source: VideoSource? = null
    private var track: VideoTrack? = null
    private var streamId = ""
    private var iceServers: List<PeerConnection.IceServer> = emptyList()
    private val viewers = HashMap<String, Viewer>()
    private val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    private var baseW = 0
    private var baseH = 0
    private var curW = 0
    private var curH = 0

    @Volatile
    var isSharing = false
        private set

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            if (displayId == Display.DEFAULT_DISPLAY) exec.execute { applyOrientation() }
        }
    }

    init {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(ctx).createInitializationOptions()
        )
        // Prefere o codificador de hardware (bem mais leve pra 1080p60)
        val hw = HardwareVideoEncoderFactory(egl.eglBaseContext, true, true)
        val enc: VideoEncoderFactory =
            if (hw.supportedCodecs.isNotEmpty()) hw
            else DefaultVideoEncoderFactory(egl.eglBaseContext, true, true)
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(enc)
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(egl.eglBaseContext))
            .createPeerConnectionFactory()
    }

    /** Começa a capturar. Retorna o id do stream. */
    fun start(data: Intent, iceJson: String, screenW: Int, screenH: Int): String {
        return exec.submit<String> {
            stopInternal(false)
            iceServers = parseIce(iceJson)

            // Limita o lado maior a 1920 (qualidade 1080p)
            var w = minOf(screenW, screenH)
            var h = maxOf(screenW, screenH)
            if (h > 1920) {
                val s = 1920.0 / h
                w = (w * s).toInt()
                h = 1920
            }
            baseW = w - (w % 2)
            baseH = h - (h % 2)
            val land = isLandscape()
            curW = if (land) baseH else baseW
            curH = if (land) baseW else baseH

            val cap = ScreenCapturerAndroid(data, object : MediaProjection.Callback() {
                override fun onStop() {
                    exec.execute { stopInternal(true) }
                }
            })
            val hlp = SurfaceTextureHelper.create("OEScreen", egl.eglBaseContext)
            val src = factory.createVideoSource(true)
            cap.initialize(hlp, ctx, src.capturerObserver)
            cap.startCapture(curW, curH, 60)

            streamId = "oe-screen-" + System.currentTimeMillis()
            track = factory.createVideoTrack("oe-screen-video", src)
            capturer = cap
            helper = hlp
            source = src
            isSharing = true
            Handler(Looper.getMainLooper()).post { dm.registerDisplayListener(displayListener, Handler(Looper.getMainLooper())) }
            streamId
        }.get()
    }

    fun stop() {
        exec.execute { stopInternal(true) }
    }

    fun release() {
        exec.execute {
            stopInternal(false)
            try { factory.dispose() } catch (_: Exception) {}
            try { egl.release() } catch (_: Exception) {}
        }
        exec.shutdown()
    }

    fun addViewer(peerId: String) {
        exec.execute {
            val t = track ?: return@execute
            viewers.remove(peerId)?.let { try { it.pc.dispose() } catch (_: Exception) {} }

            val cfg = PeerConnection.RTCConfiguration(iceServers).apply {
                sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            }
            val pc = factory.createPeerConnection(cfg, object : PeerConnection.Observer {
                override fun onSignalingChange(state: PeerConnection.SignalingState?) {}
                override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                    if (state == PeerConnection.IceConnectionState.CONNECTED) exec.execute { tuneAll() }
                }
                override fun onIceConnectionReceivingChange(receiving: Boolean) {}
                override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) {}
                override fun onIceCandidate(c: IceCandidate) {
                    val cand = JSONObject()
                        .put("candidate", c.sdp)
                        .put("sdpMid", c.sdpMid)
                        .put("sdpMLineIndex", c.sdpMLineIndex)
                    sendSignal(peerId, JSONObject().put("ch", "screen").put("dir", "toViewer").put("cand", cand).toString())
                }
                override fun onIceCandidatesRemoved(cs: Array<out IceCandidate>?) {}
                override fun onAddStream(s: MediaStream?) {}
                override fun onRemoveStream(s: MediaStream?) {}
                override fun onDataChannel(dc: DataChannel?) {}
                override fun onRenegotiationNeeded() {}
                override fun onAddTrack(r: RtpReceiver?, s: Array<out MediaStream>?) {}
            }) ?: return@execute

            viewers[peerId] = Viewer(pc)
            pc.addTransceiver(
                t,
                RtpTransceiver.RtpTransceiverInit(RtpTransceiver.RtpTransceiverDirection.SEND_ONLY, listOf(streamId))
            )

            pc.createOffer(object : SimpleSdp() {
                override fun onCreateSuccess(sdp: SessionDescription) {
                    // manda a oferta antes dos candidatos (ordem garantida)
                    val desc = JSONObject().put("type", "offer").put("sdp", sdp.description)
                    val msg = JSONObject()
                        .put("ch", "screen").put("dir", "toViewer")
                        .put("desc", desc)
                        .put("kinds", JSONObject().put(streamId, "screen"))
                    sendSignal(peerId, msg.toString())
                    pc.setLocalDescription(SimpleSdp(), sdp)
                }
            }, MediaConstraints())
            tuneAll()
        }
    }

    fun removeViewer(peerId: String) {
        exec.execute {
            viewers.remove(peerId)?.let { try { it.pc.dispose() } catch (_: Exception) {} }
            tuneAll()
        }
    }

    fun onSignal(peerId: String, json: String) {
        exec.execute {
            val v = viewers[peerId] ?: return@execute
            val o = try { JSONObject(json) } catch (_: Exception) { return@execute }
            o.optJSONObject("desc")?.let { d ->
                if (d.optString("type") == "answer") {
                    v.pc.setRemoteDescription(object : SimpleSdp() {
                        override fun onSetSuccess() {
                            exec.execute {
                                v.remoteSet = true
                                v.pending.forEach { v.pc.addIceCandidate(it) }
                                v.pending.clear()
                            }
                        }
                    }, SessionDescription(SessionDescription.Type.ANSWER, d.getString("sdp")))
                }
            }
            o.optJSONObject("cand")?.let { c ->
                val sdp = c.optString("candidate")
                if (sdp.isNotEmpty()) {
                    val ice = IceCandidate(c.optString("sdpMid", "0"), c.optInt("sdpMLineIndex", 0), sdp)
                    if (v.remoteSet) v.pc.addIceCandidate(ice) else v.pending.add(ice)
                }
            }
        }
    }

    // ---------- interno ----------

    private fun isLandscape(): Boolean {
        val r = dm.getDisplay(Display.DEFAULT_DISPLAY)?.rotation ?: Surface.ROTATION_0
        return r == Surface.ROTATION_90 || r == Surface.ROTATION_270
    }

    /** Quando o jogo vira pra paisagem, a captura vira junto. */
    private fun applyOrientation() {
        val cap = capturer ?: return
        val land = isLandscape()
        val w = if (land) baseH else baseW
        val h = if (land) baseW else baseH
        if (w != curW || h != curH) {
            curW = w
            curH = h
            try { cap.changeCaptureFormat(w, h, 60) } catch (_: Exception) {}
        }
    }

    /** Divide a internet entre os amigos: quanto mais gente, menos bitrate cada. */
    private fun tuneAll() {
        val n = maxOf(1, viewers.size)
        val bitrate = when {
            n <= 1 -> 6_000_000
            n == 2 -> 4_000_000
            else -> 2_500_000
        }
        for (v in viewers.values) {
            for (s in v.pc.senders) {
                try {
                    val p = s.parameters
                    if (p.encodings.isEmpty()) continue
                    for (e in p.encodings) {
                        e.maxBitrateBps = bitrate
                        e.maxFramerate = 60
                    }
                    s.setParameters(p)
                } catch (_: Exception) {}
            }
        }
    }

    private fun stopInternal(notify: Boolean) {
        if (!isSharing) return
        isSharing = false
        Handler(Looper.getMainLooper()).post { try { dm.unregisterDisplayListener(displayListener) } catch (_: Exception) {} }
        for (v in viewers.values) try { v.pc.dispose() } catch (_: Exception) {}
        viewers.clear()
        try { capturer?.stopCapture() } catch (_: Exception) {}
        try { capturer?.dispose() } catch (_: Exception) {}
        try { track?.dispose() } catch (_: Exception) {}
        try { source?.dispose() } catch (_: Exception) {}
        try { helper?.dispose() } catch (_: Exception) {}
        capturer = null; track = null; source = null; helper = null
        if (notify) onStopped()
    }

    private fun parseIce(json: String): List<PeerConnection.IceServer> {
        val out = ArrayList<PeerConnection.IceServer>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val u = o.get("urls")
                val urls = if (u is JSONArray) (0 until u.length()).map { u.getString(it) } else listOf(u.toString())
                val b = PeerConnection.IceServer.builder(urls)
                if (o.has("username")) b.setUsername(o.getString("username"))
                if (o.has("credential")) b.setPassword(o.getString("credential"))
                out.add(b.createIceServer())
            }
        } catch (_: Exception) {}
        if (out.isEmpty()) out.add(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer())
        return out
    }
}
