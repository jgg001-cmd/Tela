package com.oficinaemrick.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/** Mantém a call viva com o app em segundo plano e libera a captura de tela. */
class CallService : Service() {

    companion object {
        var onProjectionReady: (() -> Unit)? = null

        fun start(ctx: Context, screen: Boolean) {
            val i = Intent(ctx, CallService::class.java).putExtra("screen", screen)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, CallService::class.java))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val screen = intent?.getBooleanExtra("screen", false) ?: false
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("call", "Call", NotificationManager.IMPORTANCE_LOW))

        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notif = NotificationCompat.Builder(this, "call")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Disk Voice")
            .setContentText(if (screen) "Compartilhando a tela" else "Na call")
            .setOngoing(true)
            .setContentIntent(open)
            .build()

        var type = 0
        val mic = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (Build.VERSION.SDK_INT >= 30 && mic) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        if (Build.VERSION.SDK_INT >= 29 && screen) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION

        try {
            ServiceCompat.startForeground(this, 1, notif, type)
        } catch (e: Exception) {
            onProjectionReady = null
            stopSelf()
            return START_NOT_STICKY
        }

        if (screen) {
            val cb = onProjectionReady
            onProjectionReady = null
            cb?.invoke()
        }
        return START_NOT_STICKY
    }
}
