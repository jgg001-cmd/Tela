package com.oficinaemrick.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

class MainActivity : ComponentActivity() {

    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private var sharer: ScreenSharer? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var pendingPermission: PermissionRequest? = null
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var pendingIce = "[]"
    private var inCall = false

    private val pickFile = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCb = null
    }

    private val askMic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val req = pendingPermission
        pendingPermission = null
        if (req != null) {
            if (ok) req.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else req.deny()
        }
    }

    private val askStartup = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    private val askProjection = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            CallService.onProjectionReady = { startSharing(data) }
            CallService.start(this, true)
        } else {
            js("OENative.onScreenState(false, '')")
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        root = FrameLayout(this).apply { setBackgroundColor(0xFF060A1C.toInt()) }
        web = WebView(this)
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        // Não deixa o app ficar embaixo da barra de status / navegação / teclado
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            if (customView == null) v.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom))
            insets
        }
        WindowInsetsControllerCompat(window, root).isAppearanceLightStatusBars = false

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
        }
        web.addJavascriptInterface(Bridge(), "OEAndroid")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (!request.isForMainFrame) return false
                if (request.url.host == "appassets.androidplatform.net") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, request.url)) } catch (_: Exception) {}
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) {
                        if (hasMic()) request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                        else {
                            pendingPermission?.deny()
                            pendingPermission = request
                            askMic.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    } else request.deny()
                }
            }

            override fun onShowFileChooser(view: WebView, cb: ValueCallback<Array<Uri>>, params: WebChromeClient.FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    pickFile.launch(params.createIntent())
                    true
                } catch (_: Exception) {
                    fileCb = null
                    false
                }
            }

            override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
                enterFullscreen(view, callback)
            }

            override fun onHideCustomView() {
                exitFullscreen()
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customView != null) {
                    customCb?.onCustomViewHidden()
                    exitFullscreen()
                    return
                }
                web.evaluateJavascript("window.OENative ? OENative.back() : false") { r ->
                    if (r != "true") moveTaskToBack(true) // não fecha: a call continua
                }
            }
        })

        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        askStartup.launch(perms.toTypedArray())

        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onDestroy() {
        sharer?.release()
        sharer = null
        CallService.stop(this)
        web.destroy()
        super.onDestroy()
    }

    // ---------- ponte com o JavaScript ----------

    inner class Bridge {
        @JavascriptInterface
        fun isApp(): Boolean = true

        @JavascriptInterface
        fun callStarted() = runOnUiThread {
            inCall = true
            refreshService(sharer?.isSharing == true)
        }

        @JavascriptInterface
        fun callEnded() = runOnUiThread {
            inCall = false
            sharer?.stop()
            CallService.stop(this@MainActivity)
        }

        @JavascriptInterface
        fun startScreen(ice: String) = runOnUiThread {
            pendingIce = ice
            val mpm = getSystemService(MediaProjectionManager::class.java)
            try { askProjection.launch(mpm.createScreenCaptureIntent()) }
            catch (e: Exception) { js("OENative.onError(${JSONObject.quote("Não deu pra abrir a captura de tela.")})") }
        }

        @JavascriptInterface
        fun stopScreen() = runOnUiThread { sharer?.stop() }

        @JavascriptInterface
        fun addViewer(id: String) { sharer?.addViewer(id) }

        @JavascriptInterface
        fun removeViewer(id: String) { sharer?.removeViewer(id) }

        @JavascriptInterface
        fun signal(id: String, json: String) { sharer?.onSignal(id, json) }
    }

    // ---------- tela ----------

    private fun startSharing(data: Intent) {
        val s = sharer ?: ScreenSharer(applicationContext, ::sendSignal, ::onSharerStopped).also { sharer = it }
        try {
            val (w, h) = screenSize()
            val id = s.start(data, pendingIce, w, h)
            js("OENative.onScreenState(true, ${JSONObject.quote(id)})")
        } catch (e: Exception) {
            js("OENative.onError(${JSONObject.quote("Não deu pra compartilhar a tela: " + (e.message ?: "erro"))})")
            js("OENative.onScreenState(false, '')")
            refreshService(false)
        }
    }

    private fun sendSignal(peerId: String, json: String) {
        js("OENative.onSignal(${JSONObject.quote(peerId)}, $json)")
    }

    private fun onSharerStopped() {
        runOnUiThread {
            js("OENative.onScreenState(false, '')")
            refreshService(false)
        }
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = windowManager.maximumWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val dm = DisplayMetrics()
            windowManager.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
    }

    private fun refreshService(screen: Boolean) {
        if (screen || (inCall && hasMic())) CallService.start(this, screen) else CallService.stop(this)
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    // ---------- tela cheia dos vídeos ----------

    private fun enterFullscreen(view: View, cb: WebChromeClient.CustomViewCallback) {
        if (customView != null) { cb.onCustomViewHidden(); return }
        customView = view
        customCb = cb
        root.setPadding(0, 0, 0, 0)
        root.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        web.visibility = View.GONE
        WindowInsetsControllerCompat(window, root).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }

    private fun exitFullscreen() {
        val v = customView ?: return
        root.removeView(v)
        customView = null
        customCb = null
        web.visibility = View.VISIBLE
        WindowInsetsControllerCompat(window, root).show(WindowInsetsCompat.Type.systemBars())
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        ViewCompat.requestApplyInsets(root)
    }

    private fun js(code: String) {
        runOnUiThread { if (::web.isInitialized) web.evaluateJavascript(code, null) }
    }
}
